package wat.edu.sklep.Model

data class Login(
    val loginId: Int,
    val username: String,
    val password: String,
)