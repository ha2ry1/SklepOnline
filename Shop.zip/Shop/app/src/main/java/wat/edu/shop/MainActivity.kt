package wat.edu.shop

import android.os.Bundle
import android.view.View
import android.widget.ListView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import wat.edu.sklep.ItemApi
import wat.edu.sklep.ItemObject
import wat.edu.sklep.Model.Item


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val items: MutableList<Item> = ArrayList<Item>()

        val itemApi = ItemObject.getInstance().create(ItemApi::class.java)
        // launching a new coroutine
        GlobalScope.launch {
            val result = itemApi.getItems()
            if (result != null && result.body() != null){
                for (item in result.body()!!){
                    items.add(item)
                    println("Przedmiot "+item.name)
                }
            }else{
                println("Brak przedmiotów")
            }

            if(items.size>0){
                println("Dodaję")
                val listView = findViewById<View>(R.id.lista) as ListView
                val customAdapter = ListItemAdapter(this@MainActivity,R.layout.item_row, items)
                listView.adapter = customAdapter

            }
        }

    }
}