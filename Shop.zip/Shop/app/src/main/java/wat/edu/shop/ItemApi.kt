package wat.edu.sklep

    import retrofit2.Response
    import retrofit2.http.GET
    import retrofit2.http.Query
    import wat.edu.sklep.Model.Item

interface ItemApi {
        @GET("item/")
        suspend fun getItems() : Response<List<Item>>
    }