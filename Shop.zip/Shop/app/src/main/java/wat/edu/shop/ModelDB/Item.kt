package wat.edu.sklep.Model

data class Item(
    val id: String,
    val name: String,
    val descript: String,
    val price: Double,
    val category: String,
    val image: String
)