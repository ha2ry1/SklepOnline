package wat.edu.shop

import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.TextView
import wat.edu.sklep.Model.Item
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso

class ListItemAdapter(context: Context, resource: Int, orderModel: List<Item>) :
    ArrayAdapter<Item>(context, resource, orderModel) {

    private val resourceLayout: Int = resource
    private val mContext: Context = context

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var v: View? = convertView

        if (v == null) {
            val vi: LayoutInflater = LayoutInflater.from(mContext)
            v = vi.inflate(resourceLayout, null)
        }

        val i: Item? = getItem(position)

        if (i != null) {
            val tv1: TextView? = v?.findViewById(R.id.name)
            val tv2: TextView? = v?.findViewById(R.id.price)
            val tv3: ImageView? = v?.findViewById(R.id.img)

            if (tv1 != null) {
                tv1.text = "Zamówienie nr" + i.name
            }

            if (tv2 != null) {
                tv2.text = "ilość: " + i.price
            }

            if (tv3 != null) {
                if(i.image!=null){
                    Picasso.get().load(i.image).into(tv3)
                }else{
                    print("Brak obrazka")
                }

            }
        }

        return v ?: View(context)
    }
}